plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    compileSdk = 35 // SDK 버전 변경

    defaultConfig {
        applicationId = "com.example.sophie_app2"
        minSdk = 21
        targetSdk = 35 // targetSdk도 같은 버전으로 변경
        versionCode = 1
        versionName = "1.0"

        namespace = "com.example.sophie_app2" // 네임스페이스 추가
        ndkVersion = "27.0.12077973" // NDK 버전 추가

        // Java 호환성 설정
        compileOptions {
            sourceCompatibility = JavaVersion.VERSION_11
            targetCompatibility = JavaVersion.VERSION_11
        }

        kotlinOptions {
            jvmTarget = JavaVersion.VERSION_11.toString()
        }
    }

    buildTypes {
        release {
            // Signing config 설정 (디버그 키 사용)
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

flutter {
    source = "../.."
}