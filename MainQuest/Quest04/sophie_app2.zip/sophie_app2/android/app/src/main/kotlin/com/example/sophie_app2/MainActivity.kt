package com.example.sophie_app2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
