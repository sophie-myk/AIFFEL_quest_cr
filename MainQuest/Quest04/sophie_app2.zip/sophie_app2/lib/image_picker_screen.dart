import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import 'dart:io';

class ImagePickerScreen extends StatefulWidget {
  @override
  _ImagePickerScreenState createState() => _ImagePickerScreenState();
}

class _ImagePickerScreenState extends State<ImagePickerScreen> {
  File? _image;
  final TextEditingController _textController = TextEditingController();
  String? _comment;

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final pickedFile = await picker.getImage(source: source);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _generateComment(String text) async {
    final apiKey = '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'; // 여기에 OpenAI API 키를 입력하세요.
    final response = await http.post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: json.encode({
        'model': 'gpt-3.5-turbo',
        'messages': [
          {'role': 'user', 'content': text}
        ],
      }),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      setState(() {
        _comment = data['choices'][0]['message']['content'];
      });
    } else {
      throw Exception('Failed to generate comment');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select Image'),
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          _image == null
              ? Text('No image selected.')
              : Image.file(_image!),
          SizedBox(height: 20),
          TextField(
            controller: _textController,
            decoration: InputDecoration(
              labelText: 'Write your diary entry',
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (_textController.text.isNotEmpty) {
                _generateComment(_textController.text);
              }
            },
            child: Text('Generate Comment'),
          ),
          SizedBox(height: 20),
          _comment != null ? Text('Comment: $_comment') : Container(),
          ElevatedButton(
            onPressed: () => _pickImage(ImageSource.camera),
            child: Text('Take a Photo'),
          ),
          ElevatedButton(
            onPressed: () => _pickImage(ImageSource.gallery),
            child: Text('Select from Gallery'),
          ),
        ],
      ),
    );
  }
}