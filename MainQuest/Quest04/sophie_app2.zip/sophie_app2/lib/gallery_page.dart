import 'package:flutter/material.dart';
import 'diary_page.dart';
import 'dart:io';

class GalleryPage extends StatelessWidget {
  // 내장된 이미지 리스트 (6개 이미지)
  final List<String> _localImages = [
    'assets/images/photo1.jpg',
    'assets/images/photo2.jpg',
    'assets/images/photo3.jpg',
    'assets/images/photo4.jpg',
    'assets/images/photo5.jpg',
    'assets/images/photo6.jpg',
  ];

  void _openDiary(BuildContext context, String imagePath) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DiaryPage(imagePath: imagePath), // 문자열 경로 전달
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('InsideOut'),
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 1,
        ),
        itemCount: _localImages.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () => _openDiary(context, _localImages[index]),
            child: Image.asset(
              _localImages[index],
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Center(child: Text('Image not available'));
              },
            ),
          );
        },
      ),
    );
  }
}